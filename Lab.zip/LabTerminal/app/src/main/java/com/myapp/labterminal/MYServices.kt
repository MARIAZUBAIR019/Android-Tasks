package com.myapp.labterminal

import android.app.Service
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.nfc.Tag

class MYServices : Service() {

            val TAG ="MyService"

            override fun onBind(intent: Intent): IBinder?=null

            override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
                val datastring= intent?.getStringExtra("ExtraData")
                datastring?.let{
                    Log.d(TAG,datastring)
                }
                Thread{
                    while (true){}
                }.start()
                Log.d(TAG,"I am started")
                return START_STICKY
            }

            override fun onDestroy() {
                super.onDestroy()
                Log.d(TAG,"I am destroyed")
            }
        }