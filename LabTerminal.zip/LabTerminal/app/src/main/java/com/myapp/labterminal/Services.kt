package com.myapp.labterminal
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class Services : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_services)

        val btnstart = findViewById<Button>(R.id.btnstart)
        btnstart.setOnClickListener{
                    Intent(this,MYServices::class.java).also {
                        startService(it)
                        val text1 = findViewById<TextView>(R.id.text1)
                        text1.text="Services starts running"
                    }
                }
        val btnstop = findViewById<Button>(R.id.btnstop)
                btnstop.setOnClickListener{
                    Intent(this,MYServices::class.java).also {
                        stopService(it)
                        val text1 = findViewById<TextView>(R.id.text1)
                        text1.text="Services has been stop"
                    }
                }
        val btnsend= findViewById<Button>(R.id.btnsend)
                btnsend.setOnClickListener{
                    Intent(this,MYServices::class.java).also{
                        val data= edit.text.toString()
                        it.putExtra("Extra data",data)
                        startService(it)

                    }
                }
            }
        }