package com.myapp.labterminal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.graphics.drawable.DrawableCompat.inflate
import android.view.View.inflate

class ViewBinding : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_binding)

        var binding = ResultProfileBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val viewModel
        binding.name.text = viewModel.name
        binding.button.setOnClickListener { viewModel.userClicked() }
    }
}

class ResultProfileBinding {

}
